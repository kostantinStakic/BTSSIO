<?php
    // Connexion a la base de données avec mysqli()
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "blog";
?>