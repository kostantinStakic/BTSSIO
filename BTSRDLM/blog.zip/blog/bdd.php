<?php
// variables qui vont contenir les 
// données pour faciliter l'accès à la connexion bdd
$hostname = "localhost";
$user = "root";
$password = "";
$dbname = "blogLM";

?>