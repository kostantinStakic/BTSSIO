<?php
include("variables.php");
//connexion à la bdd
//utilisation de l'extension mysqli()
//la classe mysqli contient les attributs suivants:
//mysqli(hostname,user,password,dbname)

//instanciation de la class mysqli()
//verification de la connexion avec TRY / CATCH
try{
	$mysqli = new mysqli($hostname,$user,$password,$dbname);
	$mysqli->set_charset("utf8");

}
catch(mysqli_sql_exception $e)
{
	echo "erreur de connexion SQL : " . $e->getMessage();
	$mysqli = null;
}


//fonctions de requêtes coming soon...
function verifConnexion($mysqli,$mail,$mdp)
{
	//on va créer notre requête que nous allons stocker dans une variable
	$requete = "select * from auteur where mail_aut=? and mdp_aut=?";

	//pour sécuriser nos requetes, on ne va pas utiliser query()
	//on va preparer la requete
	$stmt = $mysqli->prepare($requete);

	//on va associer les types aux variables
	$stmt->bind_param("ss",$mail,$mdp);

	//on va executer la requete
	$stmt->execute();

	//on va recuperer le ou les resultats
	$resultat = $stmt->get_result();

	return $resultat;
}

function selectWhereIdUser($mysqli,$id)
{
	$requete = "select * from auteur where id_aut=?";
	$stmt = $mysqli->prepare($requete);
	$stmt->bind_param("i",$id);
	$stmt->execute();
	$resultat = $stmt->get_result();

	return $resultat;
}

function selectAllArticleFromConnexion($mysqli)
{
	$requete = "select * from article, auteur where article.id_aut = auteur.id_aut";
	$stmt = $mysqli->prepare($requete);
	$stmt->execute();
	$resultat = $stmt->get_result();

	return $resultat;
}

function insertArticle($mysqli,$titre,$contenu,$urlimage,$id_aut)
{
	$requete = "insert into article values(null,?,?,?,?)";
	$stmt = $mysqli->prepare($requete);
	$stmt->bind_param("sssi",$titre,$contenu,$urlimage,$id_aut);
	$stmt->execute();	
}

function deleteArticle($mysqli, $id_art)
{
	$requete = "delete from article where id_art=?";
	$stmt = $mysqli->prepare($requete);
	$stmt->bind_param("i",$id_art);
	$stmt->execute();	
}

?>